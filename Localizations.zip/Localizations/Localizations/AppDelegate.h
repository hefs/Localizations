//
//  AppDelegate.h
//  Localizations
//
//  Created by 何发松 on 16/3/18.
//  Copyright © 2016年 HeRay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

